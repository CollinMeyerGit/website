int verify_matrix(double* matrixA,double* matrixB,double* matrixC,
                 int m,int k,int n);
